# Neonix - Tienda de Ropa Online

Esta aplicación Next.js es una tienda de ropa online básica.  Se incluye una página principal, una página de productos (con datos simulados) y una API para obtener los productos.

## Instalación

1. Clona el repositorio:
   ```bash
   git clone <repositorio>
   ```
2. Instala las dependencias:
   ```bash
   npm install
   ```
3. Ejecuta el servidor de desarrollo:
   ```bash
   npm run dev
   ```

## Características

* Página principal con enlace a la página de productos.
* Página de productos que muestra una lista de productos (datos simulados).
* API para obtener los datos de productos.

## Para producción:

1. Construye la aplicación:
   ```bash
   npm run build
   ```
2. Inicia el servidor de producción:
   ```bash
   npm run start
   ```

## Notas:

* Este proyecto es un ejemplo básico.  Se requiere implementar una base de datos, autenticación, carrito de compras y otras funcionalidades para una aplicación completa.
* Las imágenes son solo marcadores de posición.  Se deben reemplazar con imágenes reales.
* La funcionalidad de comercio electrónico está ausente y debe ser implementada.
* Se recomienda utilizar una base de datos como MySQL o PostgreSQL para almacenar los datos de productos.
* Se deben implementar medidas de seguridad para proteger los datos de los usuarios.
