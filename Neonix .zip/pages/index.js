import Link from 'next/link';

// Página principal de Neonix
export default function Home() {
  return (
    <div>
      <h1>Bienvenido a Neonix</h1>
      <p>Tu tienda de ropa online.</p>
      <Link href="/products">
        <a>Ver productos</a>
      </Link>
    </div>
  );
}
