import { useState, useEffect } from 'react';

// Página de productos de Neonix
export default function Products() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    // Simulación de la obtención de datos de la API o base de datos
    const fetchProducts = async () => {
      const response = await fetch('/api/products');
      const data = await response.json();
      setProducts(data);
    };
    fetchProducts();
  }, []);

  return (
    <div>
      <h1>Productos</h1>
      <ul>
        {products.map((product) => (
          <li key={product.id}>
            <h3>{product.name}</h3>
            <p>{product.description}</p>
            <img src={product.image} alt={product.name} />
          </li>
        ))}
      </ul>
    </div>
  );
}
