// API para obtener datos de productos
export default async function handler(req, res) {
  // Simulación de datos de productos. Reemplazar con la lógica de base de datos.
  const products = [
    { id: 1, name: 'Camiseta Neonix', description: 'Camiseta de algodón 100%', image: '/images/camiseta.jpg' },
    { id: 2, name: 'Pantalón Jeans', description: 'Pantalón de mezclilla clásico', image: '/images/pantalon.jpg' },
    { id: 3, name: 'Vestido Rojo', description: 'Vestido elegante para ocasiones especiales', image: '/images/vestido.jpg' },
  ];
  res.status(200).json(products);
}
